<?php
require_once '../assets/conexion/servidor.php';

session_start();// Iniciando Sesion



if(!isset($_SESSION['login_user_sys'])){

//mysqli_close($conexion); // Cerrando la conexion
echo "<script type='text/javascript'>
      window.location='sesion.php'
      </script>"; // Redirecciona a la pagina de sesion
}else{
$usuario = $_SESSION['login_user_sys'];

if($usuario!='Administrador'){
  session_destroy();
  echo "<script type='text/javascript'>
      window.location='sesion.php'
      </script>";

}

}
$conexion->query("SET NAMES 'utf8'");
$conexion = connect($host, $port, $db_name, $db_username, $db_password);
$con=mysqli_connect($host,$db_username,$db_password,$db_name);

$query =$conexion->prepare("SELECT * FROM mostrar_cita;");

$query->execute();
$resultado =$query->fetchAll();


?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

<header>
    <title>Oasis</title>
</header>


<link rel="stylesheet" href="../assets/css/estilo_citas1.1.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">


<?php include 'header_citas.php'; ?>

<div class="btn-group justify-content-right" style="position:relative;margin-left:3vw;top:-5vh;z-index:20;">
<button type="button" class="btn btn-light dropdown-toggle" data-toggle="dropdown"><?php echo $_SESSION['login_user_sys']; ?><span class="caret"></span></button>
<ul class="dropdown-menu" role="menu">
<li><a href="cerrar_sesion.php">Cerrar sesión</a></li>

</ul>
</div>

</head>
<body>
    


<div class="fondo">

<a class="btn btn-primary talleres" id="talleres" href="citas1.php">Registrar otra cita</a>

<button type='submit' class='btn btn-success cuentas' id='nuevo_cliente' name='nuevo_cliente' data-toggle='modal' data-target="#nuevousuarioModal">Agregar cliente</button>

<button type='submit' class='btn btn-secondary cuentas' id='cuentas' name='cuentas' data-toggle='modal' data-target="#cuentasModal">Cuentas de usuarios</button>

<h1 class="titulo_taller">Citas registradas</h1>

<table class="table-responsive">
    <thead>
<tr class="fila_principal">
    <td>Nombre del Especialista</td>
    <td>Nombre de Especialidad</td>
    <td>Fecha</td>
    <td>Hora</td>
    <td>Reservado</td>
</tr>
</thead>
<?php  foreach($resultado as $taller): 
    
    $hora = $taller['Hora'];

   switch($hora){

    case '7': $hora_escrita = "7 am"; break;
    case '8': $hora_escrita = "8 am"; break;
    case '9': $hora_escrita = "9 am"; break;
    case '10': $hora_escrita = "10 am"; break;
    case '11': $hora_escrita = "11 am"; break;
    case '12': $hora_escrita = "12 pm"; break;
    case '13': $hora_escrita = "1 pm"; break;
    case '14': $hora_escrita = "2 pm"; break;
    case '15': $hora_escrita = "3 pm"; break;
    case '16': $hora_escrita = "4 pm"; break;
    case '17': $hora_escrita = "5 pm"; break;
    case '18': $hora_escrita = "6 pm"; break;
    case '19': $hora_escrita = "7 pm"; break;
    case '20': $hora_escrita = "8 pm"; break;
    case '21': $hora_escrita = "9 pm"; break;
    case '22': $hora_escrita = "10 pm"; break;

   }
    
    ?>

 

<tr class="filas_secundarias" id="color_gris" >
    <td> <a href="citas1.2.php?tallerista=<?php echo utf8_encode($taller['NombreEspecialista'])?>&taller=<?php echo utf8_encode($taller['NombreEspecialidad'])?>&calendario=<?php echo $taller['Calendario']?>&hora=<?php echo $taller['Hora']?>"> <?php echo utf8_encode($taller['NombreEspecialista'])?> </a></td>
    <td> <a href="citas1.2.php?tallerista=<?php echo utf8_encode($taller['NombreEspecialista'])?>&taller=<?php echo utf8_encode($taller['NombreEspecialidad'])?>&calendario=<?php echo $taller['Calendario']?>&hora=<?php echo $taller['Hora']?>"> <?php echo utf8_encode($taller['NombreEspecialidad'])?></a></td>
     <td><a href="citas1.2.php?tallerista=<?php echo utf8_encode($taller['NombreEspecialista'])?>&taller=<?php echo utf8_encode($taller['NombreEspecialidad'])?>&calendario=<?php echo $taller['Calendario']?>&hora=<?php echo $taller['Hora']?>"><?php echo $taller['Calendario']?></a></td>
    <td><a href="citas1.2.php?tallerista=<?php echo utf8_encode($taller['NombreEspecialista'])?>&taller=<?php echo utf8_encode($taller['NombreEspecialidad'])?>&calendario=<?php echo $taller['Calendario']?>&hora=<?php echo $taller['Hora']?>"><?php echo $hora_escrita?></a></td>
    <td><a href="citas1.2.php?tallerista=<?php echo utf8_encode($taller['NombreEspecialista'])?>&taller=<?php echo utf8_encode($taller['NombreEspecialidad'])?>&calendario=<?php echo $taller['Calendario']?>&hora=<?php echo $taller['Hora']?>"><?php echo $taller['Reservado']?></a></td>
  
    </tr>
</a>

<?php   endforeach; ?>

</table>

<!--Seccion del modal de la informacion de las cuentas-->

<!-- Modal Cuentas-->
<div class="modal fade" id="cuentasModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Cuentas de usuarios</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="citas1.1.php" method="POST"> <!--fa-solid fa-pencil-slash-->
       
         
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Administrador</label>
            <div class="input-group">
      <input id="recipient_contra_admin" name = "recipient_contra_admin"  type="Password" Class="form-control" disabled placeholder="Escribe la nueva contraseña aqui">
      <div class="input-group-append">
            <button id="show_password" class="btn btn-primary" type="button" onclick="mostrarPasswordAdmin()" > <span class="fa fa-eye-slash icon_admin"></span> </button>
            <button type="button" class="btn btn-light editar_contra_admin" id="editar_contra_admin" name="editar_contra_admin" onclick="editar_campos_admin()"><span class="fa fa-pencil edit"></span></button>
          </div>
    </div>
           
          </div>
          <div class="form-group">
                   <label for="recipient-name" class="col-form-label">Trabajador</label>
          
                   <div class="input-group">
                 <input id="recipient_contra_trabajador" name = "recipient_contra_trabajador"  type="Password" Class="form-control" disabled placeholder="Escribe la nueva contraseña aqui">
                <div class="input-group-append">
               <button id="show_password2" class="btn btn-primary" type="button" onclick="mostrarPasswordPrestador()" > <span class="fa fa-eye-slash icon_trabajador"></span> </button>
               <button type="button" class="btn btn-light editar_contra_trabajador" id="editar_contra_trabajador" name="editar_contra_trabajador" onclick="editar_campos_prestador()"><span class="fa fa-pencil edit"></span></button>
              </div>
              </div>
          </div>
         
        
          <div class="modal-footer"> 
        <button type="submit" class="btn btn-secondary"  data-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-primary guardar_cambios" id="btncuentas" name="btncuentas" hidden="true" onclick="desbloquear_campos()">Guardar cambios</button>
      </div>
        </form>
      </div>
      
    </div>
  </div>
</div>

<!--Seccion del modal de la informacion de la persona-->

<!-- Modal Agregar datos de cliente nuevo-->
<div class="modal fade" id="nuevousuarioModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Agregar cliente</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="" method="POST">
        <div class="form-group">
            <label for="recipient-name" class="col-form-label">Curp:</label>
          
            <input type="text" class="form-control" id="recipient_curp" name="recipient_curp"  required autocomplete="off">
          </div> 
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Nombre:</label>
            <input type="text" class="form-control" id="recipient_nombre"  name = "recipient_nombre"  required autocomplete="off">
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Apellidos:</label>
            <input type="text" class="form-control" id="recipient_apellido" name="recipient_apellido"  required autocomplete="off">
          </div>

          <div class="modal-footer"> 
        <button type="submit" class="btn btn-secondary"  data-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-primary" id="btnagregar" name="btnagregar">Agregar ahora</button>
      </div>
        </form>
      </div>
      
    </div>
  </div>
</div>

</div>

<!--Habilitar campos y mostrar texto de los inputs del modal de las cuentas de usuario-->
<script type="text/javascript">
function mostrarPasswordAdmin(){
		var cambio = document.getElementById("recipient_contra_admin");
		if(cambio.type == "password"){
			cambio.type = "text";
			$('.icon_admin').removeClass('fa fa-eye-slash').addClass('fa fa-eye');
		}else{
			cambio.type = "password";
			$('.icon_admin').removeClass('fa fa-eye').addClass('fa fa-eye-slash');
		}
	} 

  function mostrarPasswordPrestador(){
		var cambio = document.getElementById("recipient_contra_trabajador");
		if(cambio.type == "password"){
			cambio.type = "text";
			$('.icon_trabajador').removeClass('fa fa-eye-slash').addClass('fa fa-eye');
		}else{
			cambio.type = "password";
			$('.icon_trabajador').removeClass('fa fa-eye').addClass('fa fa-eye-slash');
		}
	} 
	
  function editar_campos_admin(){
    var cambio1 = document.getElementById("recipient_contra_admin");
    var cambio2 = document.getElementById("recipient_contra_trabajador");
    var cambio3_boton = document.getElementById("btncuentas");
    if(cambio1.disabled == true ){

      cambio3_boton.hidden = false;
			cambio1.disabled = false;
     
			$('.editar_contra_admin').removeClass('btn btn-light').addClass('btn btn-dark');
		}else{
      if(cambio2.disabled == true){
      cambio3_boton.hidden = true;
      }
      cambio1.disabled = true;
     
      $('.editar_contra_admin').removeClass('btn btn-dark').addClass('btn btn-light');
		}
  }

  function editar_campos_prestador(){
    var cambio1 = document.getElementById("recipient_contra_admin");
    var cambio2 = document.getElementById("recipient_contra_trabajador");
    var cambio3_boton = document.getElementById("btncuentas");
    if(cambio2.disabled == true){
      cambio3_boton.hidden = false;
      cambio2.disabled = false;
			$('.editar_contra_trabajador').removeClass('btn btn-light').addClass('btn btn-dark');
		}else{
      if(cambio1.disabled == true){
      cambio3_boton.hidden = true;
      }
      cambio2.disabled = true;
      $('.editar_contra_trabajador').removeClass('btn btn-dark').addClass('btn btn-light');
		}

  }

  function desbloquear_campos(){
    var cambio1 = document.getElementById("recipient_contra_admin");
    cambio1.disabled = false;
    var cambio2 = document.getElementById("recipient_contra_trabajador");
    cambio2.disabled = false;
 
  }

</script>

<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="../assets/js/sweetalert.js"></script>

<?php


//if para hacer las acciones al presionar boton de guardar cambios del modal de cuentas de usuario
if(isset($_POST['btncuentas'])){


  // se guardar los valores en variables
  $admin_contra = $_POST['recipient_contra_admin'];

  $admin_contra_encrypt = sha1($_POST['recipient_contra_admin']);

  $prestador_contra = $_POST['recipient_contra_trabajador'];
  $prestador_contra_encrypt = sha1($_POST['recipient_contra_trabajador']);
  
  $validar_contraseñas = "SELECT * FROM cuentas_usuarios";

  $contraseñas = mysqli_query($con,$validar_contraseñas);
print_r($admin_contra);
echo '<br>';
print_r($prestador_contra);
  if(!empty($admin_contra)||!empty($prestador_contra)){
  
 if($admin_contra!=$prestador_contra){ //validar que no sean iguales las contraseñas de los inputs

 

  $i=0;    
  while($filas_cuenta = mysqli_fetch_array($contraseñas)){ //while para guardar contraseñas y usuarios de la base datos en variables
    
    $user[$i] = $filas_cuenta['Usuario'];
   $password[$i] = $filas_cuenta['Contra'];
   
   $i++;
  }



 //if para validar que las contraseñas escritas en los inputs no sean las contraseñas de otro usuario en la base de datos
if(($admin_contra!=$password[1]&&$prestador_contra_encrypt!=$password[0])||empty($admin_contra)||empty($prestador_contra)){


  if($admin_contra!=$password[1]){ //if para validar que la contraseña escrita de administrador no sea la del prestador en la BD

  if(!empty($admin_contra)){ //entra si se agrega una contraseña de administrador 

if($admin_contra_encrypt!=$password[0]){//if para saber si la contraseña del administrador es diferente al de la base de datos

  //se actualiza el registro de la cuenta administrador
  $con->query("UPDATE cuentas_usuarios SET Contra = '$admin_contra_encrypt' WHERE Usuario= '$user[0]'");

  if(!empty($prestador_contra)){ //if para validar si la del prestador no  este vacio
   
    $con->query("UPDATE cuentas_usuarios SET Contra = '$prestador_contra' WHERE Usuario= '$user[1]'");
  }

  if($con){ //se muestra la ventana de exito al actualizar las contraseñas
    echo '<script>alertaNoti("Se han actualizado los datos con exito")</script>';
  }


}else{ //else que muestra un error de que la contraseña de administrador es la misma que la base de datos y no ha cambiado
  
  echo '<script>alertaeNoti("Esta contraseña de administrador es la que esta asignada actualmente")</script>';
}


  }
  }else{ //else para mostrar error de que la contraseña de administrador escrita es igual al de prestador
    echo '<script>alertaeNoti("Esta contraseña de administrador es la que esta asignada actualmente al trabajador")</script>';

  }

  //if para validar que la contraseña de prestador escrita no sea igual al de administrador en la BD
  if($prestador_contra_encrypt!=$password[0]){

  if(!empty($prestador_contra)){ //if para validar que no este vacio el campo de contraseña de prestador
  
    if($prestador_contra!=$password[1]){ //if para saber si la contraseña del prestador es diferente al de la base de datos
   
    $con->query("UPDATE cuentas_usuarios SET Contra = '$prestador_contra' WHERE Usuario= '$user[1]'");
    if($con){ //se muestra la ventana de exito al actualizar las contraseñas
      echo '<script>alertaNoti("Se han actualizado los datos con exito")</script>';
    }
  }

  }
}else{//else para mostrar error de que la contraseña de prestador escrita es igual al de administrador
  echo '<script>alertaeNoti("Esta contraseña de Usuario esta siendo usada actualmente por otro")</script>';
}
   

  }else{ //else para mostrar advertencia sobre el intercambio de contraseñas
    echo '<script>alertaeNotiwarning("No es recomendable intercambiar las contraseñas")</script>';
  }
 }else{  //else para mostrar error de contraseñas iguales
  echo '<script>alertaeNoti("Las contraseñas no deben ser iguales entre usuarios")</script>';
 }
  }else{
    echo '<script>alertaeNoti("Los campos estan vacios")</script>';
  }

}
////////////////////////////////////////////////////////////////////////////////////////

//if para hacer acciones al presionar boton de agregar ahora del modal agregar alumno
if(isset($_POST['btnagregar'])){

  //se guardan los valores en variables
$curp = $_POST['recipient_curp'];
$nombre = $_POST['recipient_nombre'];
$apellido = $_POST['recipient_apellido'];
if (strpos($curp, "'")==false){ 
//consulta para validar si ya existe alguien con el codigo que se intenta agregar
$validar_repetidos = "SELECT * FROM personas WHERE Curp = '$curp'";

$resultado_repetidos = mysqli_query($con,$validar_repetidos);


if(mysqli_num_rows($resultado_repetidos)==0){ //if para validar que no se encontro resultado de la consulta

  if (strpos($curp, " ")){ //if para validar que el codigo escrito no tenga espacios vacios
    echo '<script>alertaeNoti("La CURP no debe tener espacios vacios")</script>';
  }else{ //else para agregar al nuevo alumno

    //if para validar que nomas esten permitidos los numeros y letras mayusculas en el codigo de alumno
    if (preg_match("/^[A-Z0-9]*$/i", $curp)) {
    //se agregan los datos a la BD en la tabla personas
    $con->query("INSERT INTO personas (Nombre,Apellido,Curp) values ('$nombre','$apellido','$curp')");

    if($con){ //se muestra la ventana de exito al agregar el nuevo alumno
      echo '<script>alertaNoti("Se ha agregado con exito")</script>';
    }
  }else{
    echo '<script>alertaeNoti("La CURP solo permite números y letras mayúsculas")</script>';
  }
  }
}else{ //else para mostrar error de que ya existe el codigo en la BD
  echo '<script>alertaeNoti("Esa CURP ya está en el sistema")</script>';
}

}
}

?>


<script
      src="https://code.jquery.com/jquery-3.6.0.min.js"
      integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
      crossorigin="anonymous"
    ></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>


</body>
</html>
<?php $conexion = null;?>