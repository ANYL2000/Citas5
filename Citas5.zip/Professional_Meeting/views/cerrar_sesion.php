
<?php
session_start();
if(session_destroy()) // Destruye todas las sesiones
{
    echo "<script type='text/javascript'>
    window.location='sesion.php'
    </script>"; // Redireccionando a la pagina sesion.php
}
?>