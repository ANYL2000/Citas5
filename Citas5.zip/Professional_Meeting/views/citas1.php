<?php
require_once '../assets/conexion/servidor.php';


session_start();// Iniciando Sesion



if(!isset($_SESSION['login_user_sys'])){

//mysqli_close($conexion); // Cerrando la conexion
echo "<script type='text/javascript'>
      window.location='sesion.php'
      </script>"; // Redirecciona a la pagina de sesion
}else{
$usuario = $_SESSION['login_user_sys'];

if($usuario!='Administrador'){
  session_destroy();
  echo "<script type='text/javascript'>
      window.location='sesion.php'
      </script>";

}

}

$conexion = connect($host, $port, $db_name, $db_username, $db_password);

$con=mysqli_connect($host,$db_username,$db_password,$db_name);
$conexion->query("SET NAMES 'utf8'");
$con->query("SET NAMES 'utf8'");
/*$query =$conexion->prepare("SELECT FechaInicial, FechaFinal FROM calendario;");

$query->execute();
$resultado =$query->fetchAll();*/

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

<header>
    <title>Oasis</title>
</header>


<link rel="stylesheet" href="../assets/css/estilo_citas1.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">


<?php include 'header_citas.php'; ?>

<div class="btn-group justify-content-right" style="position:relative;margin-left:3vw;top:-5vh;z-index:20;">
<button type="button" class="btn btn-light dropdown-toggle" data-toggle="dropdown"><?php echo $_SESSION['login_user_sys']; ?><span class="caret"></span></button>
<ul class="dropdown-menu" role="menu">
<li><a href="cerrar_sesion.php">Cerrar sesión</a></li>

</ul>
</div>

</head>
<body>
    


<div class="fondo">

<h1 class="titulo_registrar">Registrar Cita</h1>

<form action="" method="POST">
  <ul>

  <li>  
                    <label for="tallerista" >Nombre Completo del Especialista
                    <input class="entrada_texto" id="nombre_tallerista" type="text" name="nombre_tallerista" required></label>
                    </li> 
            <li>  
                    <label for="name" >Nombre de la Especialidad           
                    <input class="entrada_texto" id="nombre_taller" type="text" name="nombre_taller" required></label>
                    </li> 

                     


                    <!-- <li>
                        <div class="radio_opcion"><input type="radio" name="turno" id="turno" value="Matutino" required>
                    <label for="nombre_turno">Matutino</label>   
                    </div>

                       <div class="radio_opcion"> <input type="radio" name="turno" id="turno" value="Vespertino" required>
                  <label for="nombre_turno">Vespertino</label>
                    </div>

                          </li>

                         <li>
                          <label for="tipo_taller">Dia   
                    <select name="dia" id="tipo_taller" required>

                        <option value="">Elige una opción</option>
                                <option value="Lunes">Lunes</option>
                                <option value="Martes">Martes</option>
                                <option value="Miercoles">Miercoles</option>
                                <option value="Jueves">Jueves</option>
                                <option value="Viernes">Viernes</option>
                                <option value="Sabado">Sabado</option>
                                <option value="Domingo">Domingo</option>
                            </select>
                            </label> 
                          </li>-->

                          <li>
                          <label for="tipo_taller">Dia   
                          <input type="date" name="fecha_cita" id="fecha_cita" required>

                          </li>

                    

                          <li>
                          <label for="tipo_taller">Hora   
                    <select name="hora" id="tipo_taller" required>

                        <option value="">Elige una opción</option>
                                <option value="7">7 am</option>
                                <option value="8">8 am</option>
                                <option value="9">9 am</option>
                                <option value="10">10 am</option>
                                <option value="11">11 am</option>
                                <option value="12">12 pm</option>
                                <option value="13">1 pm</option>
                                <option value="14">2 pm</option>
                                <option value="15">3 pm</option>
                                <option value="16">4 pm</option>
                                <option value="17">5 pm</option>
                                <option value="18">6 pm</option>
                                <option value="19">7 pm</option>
                                <option value="20">8 pm</option>
                                <option value="21">9 pm</option>
                                <option value="22">10 pm</option>
                            </select>
                            </label> 
                          </li>


           
                          <li>
                          <div class="botones">
                            <button type="reset" id="resetear"><img src="../assets/img/borrar.png" alt="../assets/img/borrar.png">Limpiar Campos</button>
                            <button type="submit" id="enviar" name ="enviar"><img src="../assets/img/registrar.png" alt="../assets/img/registrar.png">Registrar Cita</button>
                    
                            <a href="citas1.1.php"><button type="button" id="mostrar_talleres"><img src="../assets/img/mostrar_tablas.png" alt="../assets/img/mostrar_tablas.png">Mostrar</button></a>
                            </div>
                          </li>

                         
                         
                    </ul>
                    </form>
</div>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="../assets/js/sweetalert.js"></script>
<?php
//include "assets/conexion/servidor.php";
if(isset($_POST['enviar'])){
 
$tallerista = $_POST['nombre_tallerista'];
$nombre_taller = $_POST['nombre_taller'];
$hora = $_POST['hora'];
$dia = $_POST['fecha_cita'];

$consultar_repetidos = "SELECT * FROM registrar_cita WHERE NombreEspecialista='$tallerista' AND NombreEspecialidad= '$nombre_taller' AND Calendario = '$dia' AND Hora='$hora'";

$filas = mysqli_query($con,$consultar_repetidos);

//print_r($filas);

if(mysqli_num_rows($filas)>0){

  echo '<script>alertaeNoti("Ya existe esa cita")</script>';

}else{


$conexion->query("INSERT INTO registrar_cita (NombreEspecialista,NombreEspecialidad,Calendario,Hora,Reservado) values ('$tallerista','$nombre_taller','$dia','$hora','No')");

$conexion->query("INSERT INTO mostrar_cita (NombreEspecialista,NombreEspecialidad,Calendario,Hora,Reservado) values ('$tallerista','$nombre_taller','$dia','$hora','No')");
    
if($conexion){
 
//echo 'Registrado con exito';
echo '<script>alertaNoti("Se ha registrado la cita con exito")</script>';
 
}

}

$filas=0;


}

?>

<script
      src="https://code.jquery.com/jquery-3.6.0.min.js"
      integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
      crossorigin="anonymous"
    ></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>


</body>
</html>
<?php $con->close(); $conexion=null; ?>